package quiz2periodo;


public class Questao {
    String prompt;
    String resposta;

    public Questao(String prompt, String answer){
        this.prompt = prompt;
        this.resposta = answer;
    }
}